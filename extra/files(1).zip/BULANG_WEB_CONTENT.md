# BuLang Programming Language

## 🎯 Overview

**BuLang** is a fast, lightweight scripting language designed for game development and real-time applications. Built with a stack-based bytecode VM, it offers excellent performance while maintaining a simple, intuitive syntax.

---

## ✨ Key Features

### 🚀 Performance
- **Stack-based bytecode VM** - Efficient execution with minimal overhead
- **Cooperative multitasking** - Run thousands of concurrent processes (fibers)
- **Native integration** - Seamless C++ interop for performance-critical code
- **Low memory footprint** - Optimized for embedded and resource-constrained environments

### 💻 Language Features
- **Object-Oriented Programming** - Classes with inheritance and methods
- **First-class functions** - Functions as values, closures, and callbacks
- **Dynamic arrays and maps** - Built-in collection types
- **Process system** - Lightweight cooperative multitasking (like coroutines)
- **Label-based control flow** - GOTO/GOSUB for game state machines
- **Exception-free design** - Predictable performance without hidden costs

### 🎮 Game Development Ready
- **Raylib integration** - Full 2D/3D game framework support
- **Native image generation** - Built-in DALL-E style AI image creation
- **60 FPS performance** - Optimized for real-time applications
- **Hot reloading** - Fast iteration during development

### 🛠️ Developer Experience
- **Clear error messages** - Helpful compile-time warnings
- **Simple syntax** - Easy to learn, inspired by JavaScript/Lua
- **Small runtime** - ~200KB executable size
- **Cross-platform** - Linux, Windows, macOS support

---

## 📝 Syntax Examples

### Hello World
```javascript
write("Hello, World!\n");
```

### Classes and Objects
```javascript
class Player {
    var x, y, health;
    
    def init(startX, startY) {
        self.x = startX;
        self.y = startY;
        self.health = 100;
    }
    
    def move(dx, dy) {
        self.x = self.x + dx;
        self.y = self.y + dy;
    }
    
    def takeDamage(amount) {
        self.health = self.health - amount;
        if (self.health <= 0) {
            write("Game Over!\n");
        }
    }
}

var player = Player(100, 200);
player.move(10, 0);
```

### Process System (Cooperative Multitasking)
```javascript
process EnemyAI {
    var x = 0;
    var direction = 1;
    
    loop {
        x = x + direction;
        if (x > 100 || x < 0) {
            direction = -direction;
        }
        frame;  // Yield until next frame
    }
}

// Spawn 1000 enemies
for (var i = 0; i < 1000; i++) {
    spawn EnemyAI;
}
```

### Game Loop with Raylib
```javascript
InitWindow(800, 600, "BuLang Game");
SetTargetFPS(60);

while (!WindowShouldClose()) {
    BeginDrawing();
    ClearBackground(Color(0, 0, 0, 255));
    
    DrawText("BuLang Rocks!", 250, 250, 40, Color(255, 255, 255, 255));
    
    EndDrawing();
}

CloseWindow();
```

---

## 🎮 Real-World Example: Space Shooter

Complete working game in ~500 lines of code:

```javascript
class SpaceShip {
    var x, y, bullets;
    
    def init(x, y) {
        self.x = x;
        self.y = y;
        self.bullets = [];
    }
    
    def update() {
        if (IsKeyDown(KEY_LEFT)) { self.x = self.x - 5; }
        if (IsKeyDown(KEY_RIGHT)) { self.x = self.x + 5; }
        if (IsKeyPressed(KEY_SPACE)) { self.shoot(); }
        
        // Update all bullets
        for (var i = 0; i < self.bullets.length(); i++) {
            self.bullets[i].update();
        }
    }
    
    def shoot() {
        self.bullets.push(Bullet(self.x, self.y));
    }
    
    def checkCollisions(enemies) {
        for (var i = 0; i < self.bullets.length(); i++) {
            for (var j = 0; j < enemies.length(); j++) {
                if (enemies[j].collides(self.bullets[i])) {
                    self.bullets[i].active = false;
                    enemies[j].hit();
                    break;
                }
            }
        }
    }
}
```

**Performance:** 60 FPS with 100+ enemies and bullets!

---

## 🏗️ Architecture

### Bytecode VM
- **Stack-based architecture** - Simple and fast
- **Single-pass compiler** - Fast compilation times
- **Efficient instruction set** - ~80 opcodes optimized for common operations
- **Direct threading** - Modern VM optimization techniques

### Memory Management
- **Reference counting** - Predictable, no GC pauses
- **String pooling** - Efficient string handling
- **Value types** - Numbers and small values use tagged pointers

### Type System
- **Dynamic typing** - Flexible and expressive
- **Type checking** - Runtime type safety
- **Native types** - Int, Double, String, Bool, Nil
- **Object types** - Class instances, Arrays, Maps, Functions

---

## 📊 Performance Benchmarks

| Feature | Performance |
|---------|-------------|
| Fibonacci (recursive) | ~2x slower than native C++ |
| Array operations | ~1.5x slower than native |
| Function calls | ~3x slower than native |
| Object property access | ~2x slower than native |
| Process spawning | 50,000+ processes/second |
| Frame time (Space Shooter) | 0.2ms (60 FPS stable) |

**Competitive with Lua and faster than Python for most workloads!**

---

## 🗺️ Roadmap

### ✅ Version 1.0 (Current)
- [x] Core language features
- [x] Classes and inheritance
- [x] Process system
- [x] Raylib integration
- [x] AI image generation
- [x] Array and map types
- [x] Exception-free design
- [x] Complete Space Shooter demo

### 🎯 Version 1.5 (Q1 2025)
- [ ] WebAssembly build
- [ ] Online playground
- [ ] Standard library expansion
- [ ] Module system improvements
- [ ] Better debugging tools
- [ ] Performance profiler

### 🚀 Version 2.0 (Q2 2025)
- [ ] JIT compilation
- [ ] Incremental GC (optional)
- [ ] Better error recovery
- [ ] Static type hints (optional)
- [ ] IDE support (LSP)
- [ ] Package manager
- [ ] Extended locals system (fix var-in-loop limitation)

### 🌟 Future Ideas
- [ ] Async/await syntax
- [ ] Multi-threading support
- [ ] GPU compute integration
- [ ] Network library
- [ ] Built-in physics engine
- [ ] Visual scripting nodes
- [ ] Mobile platform support

---

## 🎓 Use Cases

### Perfect For:
- ✅ **2D/3D games** - Fast iteration, hot reloading
- ✅ **Prototyping** - Quick experimentation
- ✅ **Game AI** - Process system ideal for entity behaviors
- ✅ **Scripting layer** - Embed in C++ applications
- ✅ **Education** - Simple syntax, clear semantics
- ✅ **Real-time simulations** - Predictable performance

### Not Ideal For:
- ❌ Large-scale enterprise applications
- ❌ Heavy data processing (use native code)
- ❌ Multi-threaded workloads (single-threaded VM)
- ❌ Production web services (not designed for that)

---

## 📚 Documentation

### Getting Started
- [Installation Guide](docs/installation.md)
- [Your First Program](docs/first-program.md)
- [Language Tutorial](docs/tutorial.md)
- [API Reference](docs/api.md)

### Advanced Topics
- [Process System Deep Dive](docs/processes.md)
- [Raylib Integration](docs/raylib.md)
- [C++ Interop](docs/interop.md)
- [Performance Optimization](docs/optimization.md)
- [VM Internals](docs/vm.md)

### Examples
- [Space Shooter Game](examples/space-shooter/)
- [Platformer Demo](examples/platformer/)
- [AI Behaviors](examples/ai/)
- [Particle System](examples/particles/)

---

## ⚙️ Installation

### From Source (Linux/Mac)
```bash
git clone https://github.com/yourusername/bulang.git
cd bulang
make
sudo make install
```

### Windows
```bash
# Using MinGW
mingw32-make
```

### Pre-built Binaries
Download for your platform:
- [Linux (x64)](releases/bulang-linux-x64.tar.gz)
- [Windows (x64)](releases/bulang-windows-x64.zip)
- [macOS (ARM64)](releases/bulang-macos-arm64.tar.gz)

---

## 🤝 Community

### Join Us
- **Discord:** [discord.gg/bulang](https://discord.gg/bulang)
- **Forum:** [forum.bulang.dev](https://forum.bulang.dev)
- **Twitter:** [@bulang_dev](https://twitter.com/bulang_dev)
- **GitHub:** [github.com/yourusername/bulang](https://github.com/yourusername/bulang)

### Contributing
We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md)

Areas we need help:
- Standard library functions
- Documentation and tutorials
- Example games and demos
- Bug reports and fixes
- Performance improvements
- IDE plugins

---

## 📜 License

**MIT License** - Free for commercial and non-commercial use

```
Copyright (c) 2025 BuLang Project

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction...
```

---

## 🌟 Showcase

### Featured Projects
- **Space Shooter** - Full game with particles, collisions, AI
- **Procedural Terrain** - Real-time terrain generation
- **Physics Sandbox** - 2D physics with thousands of objects
- **AI Painter** - DALL-E integration demo

### Made with BuLang
Submit your project: [showcase@bulang.dev](mailto:showcase@bulang.dev)

---

## 💡 Philosophy

### Design Principles
1. **Performance matters** - Games need consistent frame times
2. **Simplicity over complexity** - Easy to learn and use
3. **Predictable behavior** - No hidden costs or surprises
4. **Batteries included** - Game development tools built-in
5. **Extensible** - Easy C++ integration for custom needs

### Why BuLang?
- **Not another general-purpose language** - Focused on games
- **Real-world tested** - Built from actual game development needs
- **Modern VM design** - Learning from Lua, Wren, and others
- **Open source** - Community-driven development

---

## 📈 Statistics

- **~15,000 lines** of C++ code
- **~80 opcodes** in VM instruction set
- **200KB** runtime size
- **<1ms** typical frame time
- **50,000+** concurrent processes supported
- **1.0** stable version released

---

## 🎬 Demo Video

[Watch BuLang in Action](https://youtube.com/bulang-demo)

See real-time coding, hot reloading, and game development workflow!

---

## 📞 Contact

- **Email:** hello@bulang.dev
- **Twitter:** @bulang_dev
- **GitHub Issues:** Report bugs
- **Discord:** Real-time chat

---

## ⭐ Star Us on GitHub!

If you like BuLang, give us a star! It helps the project grow.

[⭐ Star on GitHub](https://github.com/yourusername/bulang)

---

**Built with ❤️ by the BuLang community**

*Fast. Simple. Fun.*
