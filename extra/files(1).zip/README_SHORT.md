# 🚀 BuLang - Fast Scripting Language for Games

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-1.0-blue.svg)](https://github.com/yourusername/bulang/releases)
[![Platform](https://img.shields.io/badge/platform-Linux%20%7C%20Windows%20%7C%20macOS-lightgrey.svg)](https://github.com/yourusername/bulang)

> **Fast. Simple. Fun.** Build games with 60 FPS performance and clean syntax.

```javascript
class Player {
    var x, y, health;
    
    def update() {
        if (IsKeyDown(KEY_LEFT))  { self.x -= 5; }
        if (IsKeyDown(KEY_RIGHT)) { self.x += 5; }
    }
}
```

## ⚡ Features

- **🚀 Blazing Fast** - Stack-based bytecode VM, competitive with Lua
- **🎮 Game Ready** - Raylib integration, 60 FPS performance
- **🔄 50K+ Processes** - Cooperative multitasking for AI and simulations
- **💻 Simple Syntax** - Easy to learn, inspired by JavaScript/Lua
- **📦 Tiny Runtime** - ~200KB executable size
- **🎨 AI Integration** - Built-in image generation

## 🎮 Real Example

Complete Space Shooter game in ~500 lines:

```javascript
InitWindow(800, 600, "Space Shooter");
SetTargetFPS(60);

var player = SpaceShip(400, 500);
var enemies = [];

while (!WindowShouldClose()) {
    player.update();
    player.checkCollisions(enemies);
    
    BeginDrawing();
    ClearBackground(BLACK);
    player.draw();
    EndDrawing();
}
```

**Result:** 60 FPS with 100+ enemies and bullets! 🎯

## 📊 Performance

| Feature | vs Native C++ |
|---------|---------------|
| Fibonacci | ~2x slower |
| Array ops | ~1.5x slower |
| Function calls | ~3x slower |
| Process spawn | 50,000+/sec |

**Competitive with Lua, faster than Python!**

## 🚀 Quick Start

```bash
# Clone
git clone https://github.com/yourusername/bulang.git
cd bulang

# Build
make

# Run example
./bulang examples/space-shooter/main.bu
```

## 📚 Documentation

- [Installation Guide](docs/installation.md)
- [Language Tutorial](docs/tutorial.md)
- [API Reference](docs/api.md)
- [Process System](docs/processes.md)
- [Raylib Integration](docs/raylib.md)

## 🗺️ Roadmap

- ✅ **v1.0** - Core language, classes, processes, Raylib
- 🎯 **v1.5** - WebAssembly, online playground, better tools
- 🚀 **v2.0** - JIT compilation, LSP, package manager

## 🤝 Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md)

Areas needing help:
- Standard library
- Documentation
- Example games
- IDE plugins

## 📜 License

MIT License - Free for commercial use

## 🌟 Star Us!

If you like BuLang, give us a star! ⭐

---

**Made with ❤️ for game developers**

[Website](https://bulang.dev) • [Discord](https://discord.gg/bulang) • [Twitter](https://twitter.com/bulang_dev)
