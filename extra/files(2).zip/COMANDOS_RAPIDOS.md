# 🚀 COMANDOS RÁPIDOS - BuLang WebAssembly

## ⚡ Setup Inicial (copiar os ficheiros)

```bash
# Navegar para o projeto
cd /media/djoker/code/projects/cpp/wdiv

# Fazer download dos ficheiros:
# - Makefile.web
# - shell.html  
# - setup_web_build.sh
# (já tens eles!)

# Dar permissão ao script
chmod +x setup_web_build.sh
```

---

## 🔧 Opção A: Automático (Recomendado)

```bash
cd /media/djoker/code/projects/cpp/wdiv
./setup_web_build.sh
```

O script faz tudo automaticamente! ✨

---

## 🔨 Opção B: Manual Passo a Passo

### 1. Compilar Raylib para Web

```bash
cd /media/djoker/code/projects/cpp/wdiv/game/external/raylib/src
make PLATFORM=PLATFORM_WEB -B
```

**Verifica se criou `libraylib.a`:**
```bash
ls -lh libraylib.a
# Deve mostrar o ficheiro!
```

### 2. Voltar para a raiz e verificar estrutura

```bash
cd /media/djoker/code/projects/cpp/wdiv
make -f Makefile.web info
```

**Output esperado:**
```
📋 Informação do Build:
  Projeto: /media/djoker/code/projects/cpp/wdiv
  Raylib: /media/djoker/code/projects/cpp/wdiv/game/external/raylib/src
  Sources: /media/djoker/code/projects/cpp/wdiv/game/src
  Include: /media/djoker/code/projects/cpp/wdiv/game/include
  Assets: /media/djoker/code/projects/cpp/wdiv/assets
  
  Fontes encontradas: X
```

### 3. Build!

```bash
make -f Makefile.web
```

**Se der erro, vê a secção Troubleshooting abaixo!**

### 4. Run servidor web

```bash
make -f Makefile.web run
```

### 5. Abrir no browser

```
http://localhost:8000/bulang.html
```

---

## ⚙️ Comandos Úteis

```bash
# Ver ajuda
make -f Makefile.web help

# Ver info do projeto
make -f Makefile.web info

# Limpar build
make -f Makefile.web clean

# Limpar tudo (incluindo Raylib)
make -f Makefile.web clean-all

# Recompilar só Raylib
make -f Makefile.web raylib

# Build + Run em um comando
make -f Makefile.web && make -f Makefile.web run
```

---

## ⚠️ Troubleshooting

### ❌ Erro: "emcc: command not found"

```bash
# Ativar Emscripten
source /media/djoker/code/projects/emsdk/emsdk_env.sh

# Verificar
emcc --version
```

### ❌ Erro: "cannot find -lraylib"

```bash
# Verificar se libraylib.a existe
ls -lh /media/djoker/code/projects/cpp/wdiv/game/external/raylib/src/libraylib.a

# Se não existir, compilar:
cd /media/djoker/code/projects/cpp/wdiv/game/external/raylib/src
make PLATFORM=PLATFORM_WEB -B
```

### ❌ Erro: "No such file or directory" (assets)

Verifica que a pasta `assets` existe:
```bash
ls -la /media/djoker/code/projects/cpp/wdiv/assets
```

### ❌ Erro: "memory access out of bounds"

Aumenta memória no `Makefile.web`:
```makefile
EMFLAGS += -s TOTAL_MEMORY=134217728  # 128MB
# ou
EMFLAGS += -s TOTAL_MEMORY=268435456  # 256MB
```

### ❌ Browser mostra tela preta

1. Abre DevTools (F12)
2. Vê Console para erros
3. Vê Network tab se assets carregaram
4. Verifica se `main.cpp` foi modificado para web

---

## 📁 Estrutura Completa

```
/media/djoker/code/projects/cpp/wdiv/
├── Makefile.web              ← NOVO (build web)
├── shell.html                ← NOVO (HTML template)
├── setup_web_build.sh        ← NOVO (automático)
├── game/
│   ├── src/
│   │   ├── main.cpp          ← MODIFICAR para web
│   │   ├── interpreter.cpp
│   │   └── ... (outros .cpp)
│   ├── include/
│   │   ├── interpreter.hpp
│   │   └── ... (outros .hpp)
│   └── external/
│       └── raylib/
│           └── src/
│               ├── libraylib.a    ← Compilar com PLATFORM_WEB
│               └── ...
├── assets/
│   ├── space_shooter/
│   │   ├── main.bu
│   │   └── ... (scripts .bu)
│   └── ... (images, sounds, etc)
└── (após build web:)
    ├── bulang.html           ← Abrir isto no browser!
    ├── bulang.js
    ├── bulang.wasm
    └── bulang.data
```

---

## 🎯 Checklist Antes de Build

- [ ] Emscripten ativo (`emcc --version` funciona)
- [ ] Raylib compilado para web (`libraylib.a` existe)
- [ ] `Makefile.web` na raiz do projeto
- [ ] `shell.html` na raiz do projeto
- [ ] Pasta `assets` existe com os ficheiros
- [ ] `main.cpp` modificado para web (opcional para testar)

---

## 🌐 Depois de Funcionar

### Deploy no GitHub Pages

```bash
# Criar branch
git checkout -b gh-pages

# Adicionar ficheiros
git add bulang.html bulang.js bulang.wasm bulang.data shell.html
git commit -m "Web build"
git push origin gh-pages

# Ativar em: GitHub → Settings → Pages
```

URL final: `https://teu-usuario.github.io/bulang/bulang.html`

---

## 💡 Dicas

1. **Primeiro teste:** Tenta build sem modificar `main.cpp`
2. **Browser DevTools:** F12 → Console para ver erros
3. **Servidor CORS:** `python3 -m http.server` funciona!
4. **Hot Reload:** Recompila e refresh browser (Ctrl+F5)
5. **Performance:** Usa `-O3` para builds finais

---

## 🆘 Ainda com problemas?

1. ✅ Verifica que Emscripten está ativo
2. ✅ `make -f Makefile.web info` mostra paths corretos
3. ✅ `libraylib.a` existe
4. ✅ Console do browser (F12) mostra erros
5. ✅ Compara tua estrutura com a acima

---

**Boa sorte! 🚀**
