#!/bin/bash
# ============================================
# setup_web_build.sh - Automatiza setup do WebAssembly
# ============================================

set -e  # Exit on error

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Paths
PROJECT_ROOT="/media/djoker/code/projects/cpp/wdiv"
RAYLIB_SRC="$PROJECT_ROOT/game/external/raylib/src"

echo -e "${BLUE}🌐 BuLang WebAssembly Setup${NC}\n"

# Check if emcc is available
if ! command -v emcc &> /dev/null; then
    echo -e "${RED}❌ Emscripten não encontrado!${NC}"
    echo -e "Execute: source /media/djoker/code/projects/emsdk/emsdk_env.sh"
    exit 1
fi

echo -e "${GREEN}✅ Emscripten encontrado: $(emcc --version | head -n1)${NC}"

# Check project directory
if [ ! -d "$PROJECT_ROOT" ]; then
    echo -e "${RED}❌ Diretório do projeto não encontrado: $PROJECT_ROOT${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Projeto encontrado${NC}"

# Navigate to project
cd "$PROJECT_ROOT"

# Copy Makefile.web if exists
if [ -f "Makefile.web" ]; then
    echo -e "${YELLOW}⚠️  Makefile.web já existe. Backup? (y/n)${NC}"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        cp Makefile.web Makefile.web.backup
        echo -e "${GREEN}✅ Backup criado: Makefile.web.backup${NC}"
    fi
fi

# Copy shell.html if exists
if [ -f "shell.html" ]; then
    echo -e "${YELLOW}⚠️  shell.html já existe. Backup? (y/n)${NC}"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        cp shell.html shell.html.backup
        echo -e "${GREEN}✅ Backup criado: shell.html.backup${NC}"
    fi
fi

echo ""
echo -e "${BLUE}📋 Setup Checklist:${NC}"
echo ""

# 1. Check Raylib
echo -e "${BLUE}1. Verificando Raylib...${NC}"
if [ -d "$RAYLIB_SRC" ]; then
    echo -e "${GREEN}   ✅ Raylib encontrado${NC}"
    
    # Check if already compiled for web
    if [ -f "$RAYLIB_SRC/libraylib.a" ]; then
        echo -e "${GREEN}   ✅ libraylib.a já existe${NC}"
        echo -e "${YELLOW}   Recompilar? (y/n)${NC}"
        read -r response
        if [[ "$response" =~ ^[Yy]$ ]]; then
            cd "$RAYLIB_SRC"
            make PLATFORM=PLATFORM_WEB -B
            cd "$PROJECT_ROOT"
        fi
    else
        echo -e "${YELLOW}   ⚙️  Compilando Raylib para Web...${NC}"
        cd "$RAYLIB_SRC"
        make PLATFORM=PLATFORM_WEB -B
        cd "$PROJECT_ROOT"
        echo -e "${GREEN}   ✅ Raylib compilado!${NC}"
    fi
else
    echo -e "${RED}   ❌ Raylib não encontrado em: $RAYLIB_SRC${NC}"
    exit 1
fi

echo ""

# 2. Check main.cpp
echo -e "${BLUE}2. Verificando main.cpp...${NC}"
MAIN_CPP="$PROJECT_ROOT/game/src/main.cpp"
if [ -f "$MAIN_CPP" ]; then
    echo -e "${GREEN}   ✅ main.cpp encontrado${NC}"
    
    # Check if already modified for web
    if grep -q "__EMSCRIPTEN__" "$MAIN_CPP"; then
        echo -e "${GREEN}   ✅ main.cpp já tem código web${NC}"
    else
        echo -e "${YELLOW}   ⚠️  main.cpp precisa ser modificado para web${NC}"
        echo -e "   Vê: WEB_BUILD_GUIDE.md"
    fi
else
    echo -e "${RED}   ❌ main.cpp não encontrado${NC}"
fi

echo ""

# 3. Check assets
echo -e "${BLUE}3. Verificando assets...${NC}"
ASSETS_DIR="$PROJECT_ROOT/assets"
if [ -d "$ASSETS_DIR" ]; then
    ASSET_COUNT=$(find "$ASSETS_DIR" -type f | wc -l)
    echo -e "${GREEN}   ✅ Assets encontrados: $ASSET_COUNT ficheiros${NC}"
else
    echo -e "${YELLOW}   ⚠️  Diretório assets não encontrado${NC}"
fi

echo ""

# 4. Summary
echo -e "${BLUE}📦 Setup completo!${NC}"
echo ""
echo -e "${GREEN}Próximos passos:${NC}"
echo "  1. Modifica main.cpp (vê WEB_BUILD_GUIDE.md)"
echo "  2. make -f Makefile.web"
echo "  3. make -f Makefile.web run"
echo "  4. Abre http://localhost:8000/bulang.html"
echo ""

# Option to build now
echo -e "${YELLOW}Tentar build agora? (y/n)${NC}"
read -r response
if [[ "$response" =~ ^[Yy]$ ]]; then
    echo -e "${BLUE}🔨 Building...${NC}"
    make -f Makefile.web
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Build completo!${NC}"
        echo ""
        echo -e "${BLUE}Iniciar servidor? (y/n)${NC}"
        read -r response
        if [[ "$response" =~ ^[Yy]$ ]]; then
            echo -e "${GREEN}🚀 Servidor a correr em http://localhost:8000${NC}"
            echo -e "${YELLOW}Pressiona Ctrl+C para parar${NC}"
            python3 -m http.server 8000
        fi
    else
        echo -e "${RED}❌ Build falhou. Vê os erros acima.${NC}"
    fi
fi
