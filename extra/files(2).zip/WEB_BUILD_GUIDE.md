# 🌐 Modificações Necessárias para WebAssembly

## 📝 PASSO 1: Modificar main.cpp

Procura o teu `main.cpp` em `/media/djoker/code/projects/cpp/wdiv/game/src/main.cpp`

### Adicionar no topo do arquivo:

```cpp
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#include <emscripten/html5.h>
#endif
```

### Modificar a estrutura do game loop:

**ANTES (código atual):**
```cpp
int main() {
    // Init
    InitWindow(800, 600, "BuLang");
    SetTargetFPS(60);
    
    // ... setup do jogo
    
    // Game loop
    while (!WindowShouldClose()) {
        // Update
        // ...
        
        // Draw
        BeginDrawing();
        // ...
        EndDrawing();
    }
    
    CloseWindow();
    return 0;
}
```

**DEPOIS (para web):**
```cpp
// Variáveis globais do jogo (para acessar no loop)
// Mover todas as variáveis do jogo para global scope
// ou criar uma struct GameState

struct GameState {
    // Tudo que precisa ser mantido entre frames
    Interpreter* vm;
    // ... outras variáveis
};

GameState* gameState = nullptr;

// Função de update que será chamada a cada frame
void UpdateFrame() {
    if (WindowShouldClose()) {
        #ifdef __EMSCRIPTEN__
        emscripten_cancel_main_loop();
        #endif
        CloseWindow();
        return;
    }
    
    // Update
    // ... código de update aqui
    
    // Draw
    BeginDrawing();
    // ... código de draw aqui
    EndDrawing();
}

int main() {
    // Init
    InitWindow(800, 600, "BuLang");
    SetTargetFPS(60);
    
    // Setup do jogo
    gameState = new GameState();
    // ... inicialização
    
    #ifdef __EMSCRIPTEN__
    // Web: usa main loop do Emscripten
    emscripten_set_main_loop(UpdateFrame, 0, 1);
    #else
    // Desktop: loop normal
    while (!WindowShouldClose()) {
        UpdateFrame();
    }
    
    CloseWindow();
    delete gameState;
    #endif
    
    return 0;
}
```

---

## 📝 PASSO 2: Modificar File I/O

Se usas `fopen`, `std::ifstream`, etc para ler ficheiros `.bu`:

**ANTES:**
```cpp
FILE* file = fopen("assets/game.bu", "r");
```

**DEPOIS:**
```cpp
#ifdef __EMSCRIPTEN__
// Assets são montados em /assets pelo Emscripten
FILE* file = fopen("/assets/game.bu", "r");
#else
FILE* file = fopen("assets/game.bu", "r");
#endif
```

Ou melhor, criar função helper:

```cpp
std::string getAssetPath(const char* relativePath) {
    #ifdef __EMSCRIPTEN__
    return std::string("/assets/") + relativePath;
    #else
    return std::string("assets/") + relativePath;
    #endif
}

// Usar:
FILE* file = fopen(getAssetPath("game.bu").c_str(), "r");
```

---

## 📝 PASSO 3: Remover System Calls Problemáticos

**Evitar:**
- `system()` calls
- `exit()` direto (usar return)
- Threads (Emscripten não suporta facilmente)
- `std::filesystem` (pode não funcionar)

---

## 📝 PASSO 4: Criar Makefile.web no projeto

Copia o `Makefile.web` para:
```
/media/djoker/code/projects/cpp/wdiv/Makefile.web
```

Copia o `shell.html` para:
```
/media/djoker/code/projects/cpp/wdiv/shell.html
```

---

## 🔧 EXEMPLO COMPLETO: main.cpp adaptado

```cpp
#include <iostream>
#include "interpreter.hpp"

#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#include <emscripten/html5.h>
#endif

// Game State Global
struct GameState {
    Interpreter* vm;
    bool initialized;
};

GameState* g_state = nullptr;

// Helper para paths de assets
std::string getAssetPath(const char* path) {
    #ifdef __EMSCRIPTEN__
    return std::string("/assets/") + path;
    #else
    return std::string("assets/") + path;
    #endif
}

// Frame update
void UpdateFrame() {
    if (WindowShouldClose()) {
        #ifdef __EMSCRIPTEN__
        emscripten_cancel_main_loop();
        #endif
        
        if (g_state && g_state->vm) {
            delete g_state->vm;
        }
        CloseWindow();
        return;
    }
    
    // Update VM (se tiveres game loop no BuLang)
    if (g_state && g_state->vm && g_state->initialized) {
        // g_state->vm->update();
        // ou o que fizeres para rodar um frame
    }
}

int main(int argc, char* argv[]) {
    // Init Raylib
    InitWindow(800, 600, "BuLang - Web Demo");
    SetTargetFPS(60);
    
    // Init Game State
    g_state = new GameState();
    g_state->initialized = false;
    
    // Init VM
    g_state->vm = new Interpreter();
    
    // Load and run main script
    std::string mainScript = getAssetPath("space_shooter/main.bu");
    
    try {
        g_state->vm->loadAndRun(mainScript.c_str());
        g_state->initialized = true;
    } catch (const std::exception& e) {
        std::cerr << "Error loading script: " << e.what() << std::endl;
    }
    
    #ifdef __EMSCRIPTEN__
    // Web: Setup main loop
    emscripten_set_main_loop(UpdateFrame, 0, 1);
    #else
    // Desktop: Normal loop
    while (!WindowShouldClose()) {
        UpdateFrame();
    }
    
    // Cleanup
    if (g_state->vm) {
        delete g_state->vm;
    }
    delete g_state;
    CloseWindow();
    #endif
    
    return 0;
}
```

---

## 🚀 COMANDOS PARA BUILD

```bash
# Navegar para o projeto
cd /media/djoker/code/projects/cpp/wdiv

# Build
make -f Makefile.web

# Run (servidor local)
make -f Makefile.web run

# Abrir browser em: http://localhost:8000/bulang.html
```

---

## ⚠️ TROUBLESHOOTING

### Se der erro "cannot find -lraylib":
```bash
cd /media/djoker/code/projects/cpp/wdiv/game/external/raylib/src
make PLATFORM=PLATFORM_WEB -B
```

### Se der erro de memory:
Aumenta `TOTAL_MEMORY` no Makefile.web:
```makefile
EMFLAGS += -s TOTAL_MEMORY=134217728  # 128MB
```

### Se assets não carregarem:
Verifica se o path está correto no `--preload-file`

### Se não aparecer nada:
Abre o console do browser (F12) e vê os erros!

---

## 📦 Ficheiros Necessários

1. ✅ `Makefile.web` → root do projeto
2. ✅ `shell.html` → root do projeto  
3. 🔧 `main.cpp` → modificado com `#ifdef __EMSCRIPTEN__`
4. 📁 `assets/` → com os ficheiros `.bu`

---

## 🎯 RESULTADO ESPERADO

Depois de compilar com sucesso, terás:
- `bulang.html` → Página para abrir
- `bulang.js` → JavaScript gerado
- `bulang.wasm` → WebAssembly
- `bulang.data` → Assets empacotados

Abre `bulang.html` num browser e joga! 🎮

---

## 💡 DICAS

1. **Debug no Browser:**
   - F12 → Console para ver prints
   - Network tab para ver carregamento de assets
   
2. **Performance:**
   - Usa `-O3` em vez de `-O2` para release
   - Remove `-g` para builds finais
   
3. **Mobile:**
   - Adiciona `<meta name="viewport">` no HTML
   - Testa em mobile browser

---

**Próximo passo:** Modifica o `main.cpp` e faz build! 🚀
