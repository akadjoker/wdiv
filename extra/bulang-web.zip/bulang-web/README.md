# 🚀 BuLang WebAssembly - Portable Build

Esta pasta contém tudo necessário para compilar BuLang para WebAssembly.

## 📁 Estrutura

```
bulang-web/
├── README.md              ← Este ficheiro
├── setup.sh               ← Script de setup automático
├── Makefile.web           ← Build system
├── shell.html             ← HTML template
├── src/                   ← Código fonte BuLang
│   ├── main.cpp
│   ├── interpreter.cpp
│   └── ...
├── include/               ← Headers
│   ├── interpreter.hpp
│   └── ...
├── external/              ← Dependências externas
│   └── raylib/            ← Raylib (submodule ou manual)
├── assets/                ← Assets do jogo
│   └── space_shooter/
│       └── *.bu
└── build/                 ← Output da compilação
    ├── bulang.html
    ├── bulang.js
    ├── bulang.wasm
    └── bulang.data
```

---

## ⚡ Quick Start

### Opção 1: Setup Automático (Recomendado)

```bash
# Dar permissão
chmod +x setup.sh

# Executar
./setup.sh
```

### Opção 2: Manual

```bash
# 1. Clonar Raylib (se não tiver)
git clone https://github.com/raysan5/raylib.git external/raylib

# 2. Compilar Raylib para Web
cd external/raylib/src
make PLATFORM=PLATFORM_WEB -B
cd ../../..

# 3. Build BuLang
make -f Makefile.web

# 4. Run
make -f Makefile.web run
```

---

## 📋 Requisitos

- **Emscripten** instalado e ativo
- **Python 3** (para servidor web local)
- **Git** (para clonar Raylib)

### Instalar Emscripten

```bash
# Clonar emsdk
git clone https://github.com/emscripten-core/emsdk.git
cd emsdk

# Instalar
./emsdk install latest
./emsdk activate latest

# Ativar (adicionar ao .bashrc/.zshrc)
source ./emsdk_env.sh
```

---

## 🔧 Comandos Úteis

```bash
# Ver informação do projeto
make -f Makefile.web info

# Limpar build
make -f Makefile.web clean

# Recompilar Raylib
make -f Makefile.web raylib

# Build + Run
make -f Makefile.web && make -f Makefile.web run

# Ver ajuda
make -f Makefile.web help
```

---

## 🌐 Deploy Online

### GitHub Pages

```bash
git checkout -b gh-pages
git add build/
git commit -m "Web build"
git push origin gh-pages
```

Ativa em: Settings → Pages

### Netlify/Vercel

Arrasta a pasta `build/` para o site!

---

## ⚠️ Troubleshooting

### Emscripten não encontrado
```bash
source /caminho/para/emsdk/emsdk_env.sh
```

### Raylib não compila
```bash
cd external/raylib/src
make clean
make PLATFORM=PLATFORM_WEB -B
```

### Assets não carregam
Verifica que estão em `assets/` e usa paths relativos no código.

---

## 📞 Suporte

- GitHub: [link]
- Discord: [link]
- Email: [email]

---

**Built with ❤️ for game developers**
