#!/bin/bash
# ============================================
# setup.sh - BuLang WebAssembly Setup
# Portable version - works anywhere!
# ============================================

set -e  # Exit on error

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════╗"
echo "║   🚀 BuLang WebAssembly Setup 🚀    ║"
echo "╔═══════════════════════════════════════╗"
echo -e "${NC}"
echo ""

# Get current directory
PROJECT_ROOT="$(pwd)"

# Check if emcc is available
echo -e "${BLUE}📋 Checklist:${NC}"
echo ""
echo -e "${BLUE}1. Verificando Emscripten...${NC}"
if command -v emcc &> /dev/null; then
    echo -e "${GREEN}   ✅ Emscripten encontrado: $(emcc --version | head -n1)${NC}"
else
    echo -e "${RED}   ❌ Emscripten não encontrado!${NC}"
    echo ""
    echo "   Instala Emscripten:"
    echo "     git clone https://github.com/emscripten-core/emsdk.git"
    echo "     cd emsdk"
    echo "     ./emsdk install latest"
    echo "     ./emsdk activate latest"
    echo "     source ./emsdk_env.sh"
    echo ""
    exit 1
fi

echo ""
echo -e "${BLUE}2. Verificando estrutura do projeto...${NC}"

# Check directories
for dir in src include assets; do
    if [ -d "$dir" ]; then
        echo -e "${GREEN}   ✅ $dir/ encontrado${NC}"
    else
        echo -e "${YELLOW}   ⚠️  $dir/ não encontrado, criando...${NC}"
        mkdir -p "$dir"
    fi
done

# Check if source files exist
SRC_COUNT=$(find src -name "*.cpp" 2>/dev/null | wc -l)
if [ "$SRC_COUNT" -gt 0 ]; then
    echo -e "${GREEN}   ✅ $SRC_COUNT ficheiros .cpp encontrados${NC}"
else
    echo -e "${YELLOW}   ⚠️  Nenhum ficheiro .cpp em src/${NC}"
    echo -e "${YELLOW}      Copia o teu código fonte para src/${NC}"
fi

echo ""
echo -e "${BLUE}3. Verificando Raylib...${NC}"

# Check if external directory exists
if [ ! -d "external" ]; then
    echo -e "${YELLOW}   📁 Criando diretório external/${NC}"
    mkdir -p external
fi

# Check if Raylib exists
if [ -d "external/raylib" ]; then
    echo -e "${GREEN}   ✅ Raylib encontrado${NC}"
    
    # Check if compiled
    if [ -f "external/raylib/src/libraylib.a" ]; then
        echo -e "${GREEN}   ✅ libraylib.a já compilado${NC}"
        echo -e "${YELLOW}   Recompilar? (y/n)${NC}"
        read -r response
        if [[ "$response" =~ ^[Yy]$ ]]; then
            echo -e "${BLUE}   🔨 Recompilando Raylib...${NC}"
            cd external/raylib/src
            make PLATFORM=PLATFORM_WEB -B
            cd "$PROJECT_ROOT"
            echo -e "${GREEN}   ✅ Raylib recompilado!${NC}"
        fi
    else
        echo -e "${BLUE}   🔨 Compilando Raylib para Web...${NC}"
        cd external/raylib/src
        make PLATFORM=PLATFORM_WEB -B
        cd "$PROJECT_ROOT"
        echo -e "${GREEN}   ✅ Raylib compilado!${NC}"
    fi
else
    echo -e "${YELLOW}   📥 Raylib não encontrado, clonando...${NC}"
    git clone --depth 1 https://github.com/raysan5/raylib.git external/raylib
    
    echo -e "${BLUE}   🔨 Compilando Raylib para Web...${NC}"
    cd external/raylib/src
    make PLATFORM=PLATFORM_WEB -B
    cd "$PROJECT_ROOT"
    echo -e "${GREEN}   ✅ Raylib clonado e compilado!${NC}"
fi

echo ""
echo -e "${BLUE}4. Verificando build directory...${NC}"
if [ ! -d "build" ]; then
    mkdir -p build
    echo -e "${GREEN}   ✅ build/ criado${NC}"
else
    echo -e "${GREEN}   ✅ build/ já existe${NC}"
fi

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        ✅ Setup Completo! ✅          ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════╝${NC}"
echo ""

# Show summary
echo -e "${PURPLE}📊 Resumo:${NC}"
echo "  📁 Projeto: $PROJECT_ROOT"
echo "  📦 Raylib: $([ -f "external/raylib/src/libraylib.a" ] && echo "✅ Compilado" || echo "❌ Não compilado")"
echo "  💻 Ficheiros .cpp: $SRC_COUNT"
echo "  🎨 Assets: $(find assets -type f 2>/dev/null | wc -l) ficheiros"
echo ""

# Offer to build
if [ "$SRC_COUNT" -gt 0 ]; then
    echo -e "${YELLOW}🔨 Compilar BuLang agora? (y/n)${NC}"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        echo ""
        echo -e "${BLUE}🔨 Compilando...${NC}"
        make -f Makefile.web
        
        if [ $? -eq 0 ]; then
            echo ""
            echo -e "${GREEN}✅ Build completo!${NC}"
            echo ""
            echo -e "${YELLOW}🌐 Iniciar servidor web? (y/n)${NC}"
            read -r response
            if [[ "$response" =~ ^[Yy]$ ]]; then
                echo ""
                echo -e "${GREEN}🚀 Servidor a correr!${NC}"
                echo -e "${BLUE}   Abre: ${YELLOW}http://localhost:8000/bulang.html${NC}"
                echo -e "${RED}   Pressiona Ctrl+C para parar${NC}"
                echo ""
                cd build && python3 -m http.server 8000
            else
                echo ""
                echo -e "${GREEN}Para iniciar servidor mais tarde:${NC}"
                echo "  make -f Makefile.web run"
            fi
        else
            echo ""
            echo -e "${RED}❌ Build falhou!${NC}"
            echo "   Vê os erros acima."
            echo ""
            echo -e "${YELLOW}Dicas:${NC}"
            echo "  - Verifica se main.cpp está em src/"
            echo "  - Verifica se tem código web (#ifdef __EMSCRIPTEN__)"
            echo "  - Tenta: make -f Makefile.web info"
        fi
    else
        echo ""
        echo -e "${GREEN}Para compilar mais tarde:${NC}"
        echo "  make -f Makefile.web"
        echo ""
        echo -e "${GREEN}Para ver ajuda:${NC}"
        echo "  make -f Makefile.web help"
    fi
else
    echo -e "${YELLOW}⚠️  Nenhum código fonte encontrado em src/${NC}"
    echo ""
    echo -e "${GREEN}Próximos passos:${NC}"
    echo "  1. Copia os ficheiros .cpp para src/"
    echo "  2. Copia os ficheiros .hpp para include/"
    echo "  3. Copia os assets para assets/"
    echo "  4. make -f Makefile.web"
fi

echo ""
echo -e "${BLUE}📚 Documentação:${NC}"
echo "  README.md - Guia completo"
echo "  make -f Makefile.web help - Comandos disponíveis"
echo ""
