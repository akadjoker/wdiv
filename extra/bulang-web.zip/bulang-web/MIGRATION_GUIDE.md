# 📦 Como Copiar Código Existente para Este Projeto

Este guia explica como migrar o código BuLang existente para esta estrutura portátil.

---

## 🎯 Do Teu Projeto Original

Se tens o código em:
```
/media/djoker/code/projects/cpp/wdiv/
```

---

## 📋 Passo a Passo

### 1. Copiar Código Fonte (.cpp)

```bash
# Copiar TODOS os .cpp
cp /caminho/original/game/src/*.cpp bulang-web/src/

# OU copiar ficheiros específicos
cp /caminho/original/game/src/main.cpp bulang-web/src/
cp /caminho/original/game/src/interpreter.cpp bulang-web/src/
cp /caminho/original/game/src/value.cpp bulang-web/src/
# ... etc
```

### 2. Copiar Headers (.hpp)

```bash
# Copiar TODOS os .hpp
cp /caminho/original/game/include/*.hpp bulang-web/include/

# OU específicos
cp /caminho/original/game/include/interpreter.hpp bulang-web/include/
# ... etc
```

### 3. Copiar Assets

```bash
# Copiar pasta completa
cp -r /caminho/original/assets/* bulang-web/assets/

# OU específico (ex: space shooter)
cp -r /caminho/original/assets/space_shooter bulang-web/assets/
```

---

## 🔧 Ajustar Código para Web

### main.cpp

Se o teu `main.cpp` ainda não tem código web, adiciona:

```cpp
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#endif

// ... resto dos includes

// Mover variáveis globais ou criar struct
struct GameState {
    Interpreter* vm;
    // ... outras variáveis
};

GameState* g_state = nullptr;

void UpdateFrame() {
    // Código do game loop aqui
    
    #ifdef __EMSCRIPTEN__
    if (WindowShouldClose()) {
        emscripten_cancel_main_loop();
        CloseWindow();
        return;
    }
    #endif
    
    // Update
    // ...
    
    // Draw
    BeginDrawing();
    // ...
    EndDrawing();
}

int main() {
    InitWindow(800, 600, "BuLang");
    SetTargetFPS(60);
    
    // Init
    g_state = new GameState();
    // ... setup
    
    #ifdef __EMSCRIPTEN__
    emscripten_set_main_loop(UpdateFrame, 0, 1);
    #else
    while (!WindowShouldClose()) {
        UpdateFrame();
    }
    CloseWindow();
    delete g_state;
    #endif
    
    return 0;
}
```

### Paths de Assets

Se usas paths absolutos, muda para relativos:

**ANTES:**
```cpp
FILE* f = fopen("/media/djoker/.../assets/game.bu", "r");
```

**DEPOIS:**
```cpp
#ifdef __EMSCRIPTEN__
FILE* f = fopen("/assets/game.bu", "r");  // Emscripten monta em /assets
#else
FILE* f = fopen("assets/game.bu", "r");   // Desktop usa relativo
#endif
```

Ou cria helper:
```cpp
std::string getAssetPath(const char* path) {
    #ifdef __EMSCRIPTEN__
    return std::string("/assets/") + path;
    #else
    return std::string("assets/") + path;
    #endif
}
```

---

## ✅ Verificar Estrutura Final

Depois de copiar tudo:

```bash
cd bulang-web
tree -L 2
```

Deve mostrar:
```
bulang-web/
├── README.md
├── Makefile.web
├── shell.html
├── setup.sh
├── .gitignore
├── src/
│   ├── main.cpp          ✅
│   ├── interpreter.cpp   ✅
│   └── ...
├── include/
│   ├── interpreter.hpp   ✅
│   └── ...
├── assets/
│   └── space_shooter/    ✅
│       └── *.bu
├── external/
│   └── raylib/           (clonado pelo setup)
└── build/                (criado no build)
```

---

## 🚀 Testar

```bash
# Rodar setup (compila Raylib)
./setup.sh

# Verificar que encontrou os ficheiros
make -f Makefile.web info

# Build
make -f Makefile.web

# Run
make -f Makefile.web run
```

---

## 📦 Exemplo Completo de Migração

```bash
# 1. Ir para onde queres criar o projeto portátil
cd ~/Desktop

# 2. Copiar pasta bulang-web
cp -r /caminho/para/bulang-web ./

# 3. Entrar
cd bulang-web

# 4. Copiar código original
cp /media/djoker/code/projects/cpp/wdiv/game/src/*.cpp src/
cp /media/djoker/code/projects/cpp/wdiv/game/include/*.hpp include/
cp -r /media/djoker/code/projects/cpp/wdiv/assets/* assets/

# 5. Setup
chmod +x setup.sh
./setup.sh

# 6. Build
make -f Makefile.web

# 7. Run!
make -f Makefile.web run
```

---

## 💾 Criar Zip para Partilhar

```bash
# Criar zip sem build outputs
zip -r bulang-web.zip bulang-web/ \
    -x "bulang-web/build/*" \
    -x "bulang-web/external/*" \
    -x "bulang-web/.git/*"

# OU com tar.gz
tar -czf bulang-web.tar.gz \
    --exclude='build' \
    --exclude='external' \
    --exclude='.git' \
    bulang-web/
```

Envia `bulang-web.zip` para o GUI!

Ele só precisa:
1. Extrair
2. `./setup.sh`
3. DONE! 🎉

---

## 🎁 O Que Incluir no Zip

✅ **Incluir:**
- README.md
- Makefile.web
- shell.html
- setup.sh
- .gitignore
- src/ (com código)
- include/ (com headers)
- assets/ (com ficheiros do jogo)

❌ **NÃO incluir:**
- build/ (gerado na compilação)
- external/raylib (clonado pelo setup)
- .git/ (se tiver)

---

## 📝 Notas Adicionais

### Se tiver outros includes/libs

Se o projeto usa outras bibliotecas além de Raylib, adiciona ao `Makefile.web`:

```makefile
CXXFLAGS += -I/path/to/other/lib
LDFLAGS += -L/path/to/other/lib -lother
```

### Se tiver muitos ficheiros

Se tem muitos .cpp subdivididos, a estrutura atual `$(wildcard src/*.cpp)` pega todos automaticamente!

Se tiver subdirectórios em `src/`:
```makefile
SOURCES = $(shell find $(SRC_DIR) -name '*.cpp')
```

---

**Pronto! Projeto portátil e auto-contido!** 📦✨
