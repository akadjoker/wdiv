#!/bin/bash
# ============================================
# copy_from_original.sh
# Copia código do projeto original para bulang-web
# ============================================

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}📦 Copiar código do projeto original${NC}"
echo ""

# Ask for original project path
echo -e "${YELLOW}Caminho do projeto original?${NC}"
echo "Exemplo: /media/djoker/code/projects/cpp/wdiv"
read -r ORIGINAL_PATH

# Validate path
if [ ! -d "$ORIGINAL_PATH" ]; then
    echo -e "${RED}❌ Caminho não encontrado: $ORIGINAL_PATH${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}✅ Caminho válido${NC}"
echo ""

# Copy source files
echo -e "${BLUE}📄 Copiando ficheiros .cpp...${NC}"
if [ -d "$ORIGINAL_PATH/game/src" ]; then
    cp -v "$ORIGINAL_PATH/game/src"/*.cpp src/ 2>/dev/null
    CPP_COUNT=$(ls src/*.cpp 2>/dev/null | wc -l)
    echo -e "${GREEN}✅ $CPP_COUNT ficheiros .cpp copiados${NC}"
else
    echo -e "${YELLOW}⚠️  Pasta src não encontrada em $ORIGINAL_PATH/game/src${NC}"
fi

echo ""

# Copy header files
echo -e "${BLUE}📄 Copiando ficheiros .hpp...${NC}"
if [ -d "$ORIGINAL_PATH/game/include" ]; then
    cp -v "$ORIGINAL_PATH/game/include"/*.hpp include/ 2>/dev/null
    HPP_COUNT=$(ls include/*.hpp 2>/dev/null | wc -l)
    echo -e "${GREEN}✅ $HPP_COUNT ficheiros .hpp copiados${NC}"
else
    echo -e "${YELLOW}⚠️  Pasta include não encontrada em $ORIGINAL_PATH/game/include${NC}"
fi

echo ""

# Copy assets
echo -e "${BLUE}🎨 Copiando assets...${NC}"
if [ -d "$ORIGINAL_PATH/assets" ]; then
    cp -rv "$ORIGINAL_PATH/assets"/* assets/ 2>/dev/null
    ASSET_COUNT=$(find assets -type f 2>/dev/null | wc -l)
    echo -e "${GREEN}✅ $ASSET_COUNT ficheiros de assets copiados${NC}"
else
    echo -e "${YELLOW}⚠️  Pasta assets não encontrada em $ORIGINAL_PATH/assets${NC}"
fi

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         ✅ Cópia Completa! ✅        ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════╝${NC}"
echo ""

# Summary
echo -e "${BLUE}📊 Resumo:${NC}"
echo "  Código: $CPP_COUNT .cpp + $HPP_COUNT .hpp"
echo "  Assets: $ASSET_COUNT ficheiros"
echo ""

# Next steps
echo -e "${YELLOW}🚀 Próximos passos:${NC}"
echo "  1. ./setup.sh              (setup Emscripten + Raylib)"
echo "  2. make -f Makefile.web    (compilar)"
echo "  3. make -f Makefile.web run (testar)"
echo ""

# Offer to run setup
echo -e "${YELLOW}Executar setup agora? (y/n)${NC}"
read -r response
if [[ "$response" =~ ^[Yy]$ ]]; then
    ./setup.sh
fi
