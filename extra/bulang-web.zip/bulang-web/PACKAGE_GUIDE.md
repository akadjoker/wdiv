# 📦 Como Preparar para Enviar ao GUI

## 🎯 Objetivo

Criar um pacote **auto-contido** e **portátil** que o GUI possa:
1. Extrair em qualquer lugar
2. Executar `./setup.sh`
3. DONE! Tudo funciona! ✨

---

## 📋 Checklist do Que Incluir

### ✅ Ficheiros Essenciais (Sempre)
- `README.md` - Documentação principal
- `QUICKSTART.txt` - Guia rápido
- `Makefile.web` - Build system
- `shell.html` - Template HTML
- `setup.sh` - Setup automático ⭐
- `copy_from_original.sh` - Helper para copiar código
- `.gitignore` - Git ignore
- `MIGRATION_GUIDE.md` - Guia de migração

### ✅ Pastas com Código (Se Tiveres)
- `src/` - Ficheiros .cpp
- `include/` - Ficheiros .hpp
- `assets/` - Assets do jogo

### ❌ NÃO Incluir
- `build/` - Gerado na compilação
- `external/raylib/` - Clonado pelo setup.sh
- `.git/` - Não necessário

---

## 📦 Opção 1: Zip Vazio (Para GUI Adicionar Código)

Se queres enviar apenas a **estrutura** para o GUI adicionar código dele:

```bash
cd /caminho/onde/está/bulang-web
cd ..

# Criar zip SEM código
zip -r bulang-web-empty.zip bulang-web/ \
    -x "bulang-web/build/*" \
    -x "bulang-web/external/*" \
    -x "bulang-web/.git/*" \
    -x "bulang-web/src/*.cpp" \
    -x "bulang-web/include/*.hpp" \
    -x "bulang-web/assets/*"
```

**Conteúdo:**
- ✅ Scripts e Makefiles
- ✅ Documentação
- ✅ Pastas vazias (com .gitkeep)
- ❌ Sem código
- ❌ Sem assets

**GUI faz:**
1. Extrai zip
2. Copia código dele para `src/` e `include/`
3. Copia assets para `assets/`
4. `./setup.sh`
5. DONE!

---

## 📦 Opção 2: Zip Completo (Com Teu Código)

Se queres enviar tudo **pronto** incluindo teu código:

```bash
# Primeiro, copia teu código para bulang-web/
cd bulang-web
./copy_from_original.sh
# ou manualmente:
# cp /caminho/original/src/*.cpp src/
# cp /caminho/original/include/*.hpp include/
# cp -r /caminho/original/assets/* assets/

# Depois, comprimir
cd ..
zip -r bulang-web-full.zip bulang-web/ \
    -x "bulang-web/build/*" \
    -x "bulang-web/external/*" \
    -x "bulang-web/.git/*"
```

**Conteúdo:**
- ✅ Scripts e Makefiles
- ✅ Documentação
- ✅ Código fonte completo
- ✅ Headers
- ✅ Assets
- ❌ Sem build/ (gerado)
- ❌ Sem external/ (clonado)

**GUI faz:**
1. Extrai zip
2. `./setup.sh`
3. DONE! Já compila e roda!

---

## 📦 Opção 3: Tar.gz (Alternativa ao Zip)

```bash
# Vazio
tar -czf bulang-web-empty.tar.gz \
    --exclude='build' \
    --exclude='external' \
    --exclude='.git' \
    --exclude='src/*.cpp' \
    --exclude='include/*.hpp' \
    --exclude='assets/*' \
    bulang-web/

# Completo
tar -czf bulang-web-full.tar.gz \
    --exclude='build' \
    --exclude='external' \
    --exclude='.git' \
    bulang-web/
```

---

## 📝 Instruções para GUI

Cria um ficheiro `INSTRUÇÕES_GUI.txt`:

```
🚀 BuLang WebAssembly - Setup Rápido

1. EXTRAIR
   unzip bulang-web.zip
   cd bulang-web

2. SETUP (faz tudo automaticamente!)
   chmod +x setup.sh
   ./setup.sh

3. ABRIR BROWSER
   http://localhost:8000/bulang.html

REQUISITO:
- Emscripten instalado e ativo
  (o setup avisa se não tiver)

PROBLEMAS?
- Lê README.md
- Vê QUICKSTART.txt
```

---

## 🎯 Tamanhos Esperados

**Zip Vazio:** ~50KB
- Só scripts e docs

**Zip com Código:** ~200KB - 2MB
- Depende do tamanho do código e assets

**Zip com Raylib Compilado:** ~15MB
- Se quiseres incluir Raylib pré-compilado
- **NÃO recomendado** - melhor clonar!

---

## ✅ Verificação Final

Antes de enviar, verifica:

```bash
# Extrair em pasta temporária
mkdir /tmp/test-bulang
cd /tmp/test-bulang
unzip /caminho/para/bulang-web.zip

# Testar setup
cd bulang-web
./setup.sh

# Se funcionar, está pronto! ✅
```

---

## 📧 Enviar ao GUI

### Via Email
```bash
# Comprimir
zip -r bulang-web.zip bulang-web/ -x ...

# Enviar bulang-web.zip
```

### Via Git
```bash
cd bulang-web
git init
git add .
git commit -m "BuLang WebAssembly portable build"
git remote add origin https://github.com/user/bulang-web.git
git push -u origin main

# Partilhar link do GitHub
```

### Via Drive/Dropbox
1. Upload bulang-web.zip
2. Partilhar link

---

## 🎉 Resultado Final

GUI recebe:
- ✅ Estrutura completa
- ✅ Scripts automatizados
- ✅ Documentação clara
- ✅ Zero configuração manual
- ✅ Funciona em qualquer Linux/Mac com Emscripten

Basta:
1. Extrair
2. `./setup.sh`
3. Joga no browser! 🎮

---

**Simples. Portátil. Auto-contido.** 📦✨
