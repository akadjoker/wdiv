// exemplo_pathfinding_tilemap.cpp - Demonstração completa
#include "raylib.h"
#include "TilemapPathfinding.h"
#include "Graph.h"
#include "LayerSystem_Graph.h"

const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;
const int TILE_SIZE = 32;
const int GRID_WIDTH = 40;   // 1280 / 32
const int GRID_HEIGHT = 22;  // 720 / 32

int main()
{
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Pathfinding + Tilemap Demo");
    SetTargetFPS(60);
    
    // Criar tilemap
    Tilemap tilemap(GRID_WIDTH, GRID_HEIGHT, TILE_SIZE, TILE_SIZE);
    
    // ===== CRIAR MAPA COM OBSTÁCULOS =====
    // Padrão: 0 = vazio, 1 = chão, 2 = parede
    
    // Preencher com chão
    for (int y = 0; y < GRID_HEIGHT; y++)
    {
        for (int x = 0; x < GRID_WIDTH; x++)
        {
            tilemap.setTile(x, y, 1, true);  // Tudo passável
        }
    }
    
    // Criar obstáculos (paredes bloqueadas)
    // Parede horizontal
    for (int x = 10; x < 20; x++)
    {
        tilemap.setTile(x, 10, 2, false);  // tileID 2, não passável
    }
    
    // Parede vertical
    for (int y = 5; y < 15; y++)
    {
        tilemap.setTile(25, y, 2, false);
    }
    
    // Caixa
    for (int x = 30; x < 35; x++)
    {
        for (int y = 15; y < 20; y++)
        {
            tilemap.setTile(x, y, 2, false);
        }
    }
    
    // ===== OU CARREGAR DE IMAGEM (PRETO/BRANCO) =====
    // tilemap.loadPassabilityMask("assets/level_mask.png");
    
    // ===== CRIAR ENTIDADES COM PATHFINDING =====
    
    // Player (controlado manualmente)
    PathfindingEntity player(&tilemap);
    player.x = 100;
    player.y = 100;
    player.speed = 200.0f;
    
    // Inimigos (seguem player com pathfinding)
    std::vector<PathfindingEntity> enemies;
    
    for (int i = 0; i < 3; i++)
    {
        PathfindingEntity enemy(&tilemap);
        enemy.x = 200 + i * 150;
        enemy.y = 300;
        enemy.speed = 80.0f;
        enemies.push_back(enemy);
    }
    
    // ===== VARIÁVEIS =====
    
    int selectedEnemy = 0;
    bool showMask = false;
    bool showGrid = false;
    bool showPath = false;
    bool debugMode = false;
    
    // ===== LOOP PRINCIPAL =====
    
    while (!WindowShouldClose())
    {
        float dt = GetFrameTime();
        
        // ===== INPUT =====
        
        // Player - click to move
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        {
            float mouseX = GetMouseX();
            float mouseY = GetMouseY();
            player.followPath(mouseX, mouseY);
        }
        
        // Arrow keys
        if (IsKeyDown(KEY_LEFT))  player.x -= 200 * dt;
        if (IsKeyDown(KEY_RIGHT)) player.x += 200 * dt;
        if (IsKeyDown(KEY_UP))    player.y -= 200 * dt;
        if (IsKeyDown(KEY_DOWN))  player.y += 200 * dt;
        
        // Enemies - pathfind to player every second
        static float pathfindTimer = 0;
        pathfindTimer += dt;
        
        if (pathfindTimer >= 1.0f)
        {
            for (auto& enemy : enemies)
            {
                enemy.followPath(player.x, player.y);
            }
            pathfindTimer = 0;
        }
        
        // Toggle debug modes
        if (IsKeyPressed(KEY_M)) showMask = !showMask;
        if (IsKeyPressed(KEY_G)) showGrid = !showGrid;
        if (IsKeyPressed(KEY_P)) showPath = !showPath;
        if (IsKeyPressed(KEY_D)) debugMode = !debugMode;
        
        // ===== UPDATE =====
        
        player.update(dt);
        for (auto& enemy : enemies)
        {
            enemy.update(dt);
        }
        
        // ===== RENDER =====
        
        BeginDrawing();
        ClearBackground({20, 20, 40, 255});
        
        // Draw tiles (simples)
        for (int y = 0; y < GRID_HEIGHT; y++)
        {
            for (int x = 0; x < GRID_WIDTH; x++)
            {
                Tile* tile = tilemap.getTile(x, y);
                if (tile && tile->tileID == 2)
                {
                    // Parede
                    DrawRectangle(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE, DARKGRAY);
                }
                else if (showGrid)
                {
                    // Grid lines
                    DrawRectangleLines(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE, 
                                      ColorAlpha(LIGHTGRAY, 0.3f));
                }
            }
        }
        
        // Draw passability mask (debug)
        if (showMask)
        {
            tilemap.getMask()->debugRender();
        }
        
        // Draw player path
        if (showPath && player.hasPath())
        {
            for (size_t i = 0; i < player.path.size() - 1; i++)
            {
                DrawLineV(Vector2(player.path[i].first, player.path[i].second),
                         Vector2(player.path[i + 1].first, player.path[i + 1].second), YELLOW);
            }
        }
        
        // Draw player
        DrawCircle((int)player.x, (int)player.y, 10, BLUE);
        DrawCircleLines((int)player.x, (int)player.y, 10, LIGHTBLUE);
        
        // Draw enemies and their paths
        for (size_t e = 0; e < enemies.size(); e++)
        {
            auto& enemy = enemies[e];
            
            // Draw path
            if (showPath && enemy.hasPath())
            {
                Color pathColor = (e == selectedEnemy) ? YELLOW : ColorAlpha(RED, 0.5f);
                for (size_t i = 0; i < enemy.path.size() - 1; i++)
                {
                    DrawLineV(Vector2(enemy.path[i].first, enemy.path[i].second),
                             Vector2(enemy.path[i + 1].first, enemy.path[i + 1].second), pathColor);
                }
            }
            
            // Draw enemy
            Color enemyColor = (e == selectedEnemy) ? YELLOW : RED;
            DrawCircle((int)enemy.x, (int)enemy.y, 8, enemyColor);
            DrawCircleLines((int)enemy.x, (int)enemy.y, 8, DARKRED);
        }
        
        // Draw mouse target
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        {
            DrawCircle(GetMouseX(), GetMouseY(), 5, LIME);
        }
        
        // ===== UI =====
        
        DrawRectangle(10, 10, 500, 250, ColorAlpha(BLACK, 0.8f));
        
        DrawText("PATHFINDING + TILEMAP DEMO", 20, 20, 16, YELLOW);
        DrawText("Click to move player, enemies pathfind to you", 20, 40, 11, LIGHTGRAY);
        
        DrawText("Controls:", 20, 65, 12, WHITE);
        DrawText("LEFT CLICK - Move player (shows path)", 20, 80, 10, LIGHTGRAY);
        DrawText("ARROWS - Manual player movement", 20, 95, 10, LIGHTGRAY);
        DrawText("M - Toggle passability mask", 20, 110, 10, LIGHTGRAY);
        DrawText("G - Toggle grid", 20, 125, 10, LIGHTGRAY);
        DrawText("P - Toggle paths", 20, 140, 10, LIGHTGRAY);
        DrawText("D - Toggle debug", 20, 155, 10, LIGHTGRAY);
        
        DrawText("Legend:", 20, 180, 12, WHITE);
        DrawCircle(30, 195, 5, BLUE);
        DrawText("Player", 40, 190, 10, LIGHTGRAY);
        
        DrawCircle(130, 195, 5, RED);
        DrawText("Enemy", 140, 190, 10, LIGHTGRAY);
        
        DrawRectangle(220, 185, 15, 15, DARKGRAY);
        DrawText("Wall", 240, 190, 10, LIGHTGRAY);
        
        // Debug info
        DrawRectangle(SCREEN_WIDTH - 320, 10, 310, 150, ColorAlpha(BLACK, 0.8f));
        
        int playerGridX, playerGridY;
        tilemap.getMask()->worldToGrid(player.x, player.y, playerGridX, playerGridY);
        
        DrawText(TextFormat("Player: (%.0f, %.0f) Grid: (%d, %d)", 
                 player.x, player.y, playerGridX, playerGridY),
                 SCREEN_WIDTH - 310, 20, 11, YELLOW);
        
        DrawText(TextFormat("Enemies: %zu", enemies.size()), 
                 SCREEN_WIDTH - 310, 40, 11, GREEN);
        
        for (size_t i = 0; i < enemies.size(); i++)
        {
            int eGridX, eGridY;
            tilemap.getMask()->worldToGrid(enemies[i].x, enemies[i].y, eGridX, eGridY);
            Color c = (i == selectedEnemy) ? YELLOW : LIGHTGRAY;
            DrawText(TextFormat("Enemy %zu: (%.0f, %.0f) Path: %zu", 
                     i, enemies[i].x, enemies[i].y, enemies[i].path.size()),
                     SCREEN_WIDTH - 310, 55 + i * 15, 10, c);
        }
        
        DrawText(TextFormat("FPS: %d", GetFPS()), SCREEN_WIDTH - 310, 120, 11, GREEN);
        
        // Debug overlay
        if (debugMode)
        {
            DrawText("DEBUG MODE", 10, SCREEN_HEIGHT - 30, 14, LIME);
            DrawText("M: Mask | G: Grid | P: Paths", 200, SCREEN_HEIGHT - 30, 11, LIME);
        }
        
        // Instru õesdas
        DrawText("Press M, G, P, D for toggles", 10, SCREEN_HEIGHT - 30, 10, DARKGRAY);
        
        EndDrawing();
    }
    
    CloseWindow();
    return 0;
}

/*
COMPILAÇÃO:
g++ -std=c++17 exemplo_pathfinding_tilemap.cpp Graph.cpp -o pathfinding -lraylib -lm

FEATURES:
✓ Máscara de passabilidade (preto/branco)
✓ Pathfinding A* completo
✓ Múltiplos inimigos com pathfinding
✓ Colisão de obstáculos
✓ Grid-based movement
✓ Visualização de caminhos
✓ Debug overlay

COMO FUNCIONA:
1. Tilemap define obstáculos
2. Máscara (branco/preto) define passabilidade
3. A* encontra caminho mais curto
4. Entidades seguem caminho
5. Inimigos recalculam pathfinding dinamicamente

PRÓXIMAS EXPANSÕES:
- Carregar máscara de imagem PNG
- Custos diferentes por terreno
- Dijkstra/JPS para melhor performance
- Smooth pathfinding (Catmull-Rom)
- Steering behaviors
*/
