// exemplo_mask_advanced.cpp - Máscara de imagem + pathfinding
#include "raylib.h"
#include "TilemapPathfinding.h"

const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;
const int TILE_SIZE = 32;

int main()
{
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Advanced Mask + Pathfinding");
    SetTargetFPS(60);
    
    int gridW = SCREEN_WIDTH / TILE_SIZE;
    int gridH = SCREEN_HEIGHT / TILE_SIZE;
    
    Tilemap tilemap(gridW, gridH, TILE_SIZE, TILE_SIZE);
    
    // ===== OPÇÃO 1: CARREGAR MÁSCARA DE IMAGEM =====
    // Criar imagem de teste (preto/branco)
    Image maskImage = GenImageColor(gridW, gridH, BLACK);
    
    // Desenhar padrões (branco = bloqueado)
    // Parede horizontal
    for (int x = 10; x < 20; x++)
    {
        ImageDrawPixel(&maskImage, x, 10, WHITE);
    }
    
    // Parede vertical
    for (int y = 5; y < 15; y++)
    {
        ImageDrawPixel(&maskImage, 25, y, WHITE);
    }
    
    // Círculo de obstáculos
    for (int y = 15; y < 20; y++)
    {
        for (int x = 30; x < 35; x++)
        {
            float dx = x - 32.5f;
            float dy = y - 17.5f;
            if (dx*dx + dy*dy < 5*5)
                ImageDrawPixel(&maskImage, x, y, WHITE);
        }
    }
    
    // Salvar máscara (para debug)
    ExportImage(maskImage, "level_mask.png");
    
    // Carregar máscara
    tilemap.loadPassabilityMask("level_mask.png");
    UnloadImage(maskImage);
    
    // ===== ENTIDADES =====
    
    PathfindingEntity player(&tilemap);
    player.x = 100;
    player.y = 100;
    player.speed = 150.0f;
    
    std::vector<PathfindingEntity> enemies;
    for (int i = 0; i < 2; i++)
    {
        PathfindingEntity enemy(&tilemap);
        enemy.x = 300 + i * 200;
        enemy.y = 400;
        enemy.speed = 100.0f;
        enemies.push_back(enemy);
    }
    
    // ===== VARIÁVEIS =====
    bool showMask = true;
    bool showPath = true;
    float pathfindInterval = 0.5f;
    float pathfindTimer = 0;
    
    // ===== LOOP =====
    
    while (!WindowShouldClose())
    {
        float dt = GetFrameTime();
        
        // Input
        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
        {
            player.followPath(GetMouseX(), GetMouseY());
        }
        
        if (IsKeyDown(KEY_LEFT))  player.x -= 150 * dt;
        if (IsKeyDown(KEY_RIGHT)) player.x += 150 * dt;
        if (IsKeyDown(KEY_UP))    player.y -= 150 * dt;
        if (IsKeyDown(KEY_DOWN))  player.y += 150 * dt;
        
        if (IsKeyPressed(KEY_M)) showMask = !showMask;
        if (IsKeyPressed(KEY_P)) showPath = !showPath;
        
        // Pathfinding update
        pathfindTimer += dt;
        if (pathfindTimer >= pathfindInterval)
        {
            for (auto& enemy : enemies)
            {
                enemy.followPath(player.x, player.y);
            }
            pathfindTimer = 0;
        }
        
        // Update entities
        player.update(dt);
        for (auto& enemy : enemies)
        {
            enemy.update(dt);
        }
        
        // ===== RENDER =====
        
        BeginDrawing();
        ClearBackground({20, 20, 40, 255});
        
        // Draw passability mask
        if (showMask)
        {
            tilemap.getMask()->debugRender();
        }
        
        // Draw paths
        if (showPath)
        {
            if (player.hasPath())
            {
                for (size_t i = 0; i < player.path.size() - 1; i++)
                {
                    DrawLineV(
                        Vector2(player.path[i].first, player.path[i].second),
                        Vector2(player.path[i + 1].first, player.path[i + 1].second),
                        YELLOW
                    );
                }
            }
            
            for (auto& enemy : enemies)
            {
                if (enemy.hasPath())
                {
                    for (size_t i = 0; i < enemy.path.size() - 1; i++)
                    {
                        DrawLineV(
                            Vector2(enemy.path[i].first, enemy.path[i].second),
                            Vector2(enemy.path[i + 1].first, enemy.path[i + 1].second),
                            ColorAlpha(RED, 0.6f)
                        );
                    }
                }
            }
        }
        
        // Draw entities
        DrawCircle((int)player.x, (int)player.y, 10, BLUE);
        DrawCircleLines((int)player.x, (int)player.y, 10, LIGHTBLUE);
        
        for (auto& enemy : enemies)
        {
            DrawCircle((int)enemy.x, (int)enemy.y, 8, RED);
            DrawCircleLines((int)enemy.x, (int)enemy.y, 8, DARKRED);
        }
        
        // UI
        DrawRectangle(10, 10, 400, 150, ColorAlpha(BLACK, 0.8f));
        DrawText("ADVANCED PATHFINDING", 20, 20, 14, YELLOW);
        DrawText("Click to move player", 20, 40, 11, LIGHTGRAY);
        DrawText("Enemies pathfind to you", 20, 55, 11, LIGHTGRAY);
        DrawText("M - Toggle mask visibility", 20, 75, 10, LIGHTGRAY);
        DrawText("P - Toggle path visualization", 20, 90, 10, LIGHTGRAY);
        DrawText(TextFormat("FPS: %d", GetFPS()), 20, 110, 11, GREEN);
        DrawText(TextFormat("Player: (%.0f, %.0f)", player.x, player.y), 20, 130, 10, YELLOW);
        
        EndDrawing();
    }
    
    CloseWindow();
    return 0;
}

/*
ESTA VERSÃO:
✓ Carrega máscara de imagem PNG
✓ Preto = passável, Branco = bloqueado
✓ Pathfinding automático para múltiplos inimigos
✓ Visualização de caminhos
✓ Performance otimizada

COMO USAR:

1. Criar imagem máscara (PNG preto/branco):
   - Preto (#000000) = passável
   - Branco (#FFFFFF) = bloqueado

2. Carregar:
   tilemap.loadPassabilityMask("your_mask.png");

3. Usar pathfinding:
   auto path = tilemap.findPath(startX, startY, endX, endY);

4. Entidades seguem caminho:
   entity.followPath(targetX, targetY);
   entity.update(dt);

FORMATO DE MÁSCARA:
- Resolução: N x M pixels
- Cada pixel = 1 tile (32x32)
- Preto = passável (0)
- Branco = bloqueado (255)
- Cinza = semi-passável (transição)
*/
