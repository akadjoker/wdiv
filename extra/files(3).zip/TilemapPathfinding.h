#pragma once

#include "raylib.h"
#include "Graph.h"
#include <vector>
#include <cstring>
#include <queue>
#include <cmath>

// ===== PASSABILITY MASK =====
// Preto = Passável, Branco = Não passável

struct PassabilityMask
{
    uint8_t* data;          // Bitmap: 0 = passável, 255 = bloqueado
    int width, height;      // Dimensões em pixels
    int tileSize;           // Tamanho de cada tile
    
    PassabilityMask(int w, int h, int tSize)
        : width(w), height(h), tileSize(tSize)
    {
        data = new uint8_t[w * h];
        memset(data, 0, w * h);  // Tudo passável por default
    }
    
    ~PassabilityMask()
    {
        if (data) delete[] data;
    }
    
    // Carregar máscara de imagem (preto/branco)
    void loadFromImage(const char* filename)
    {
        Image img = LoadImage(filename);
        
        // Converter para passabilidade
        for (int y = 0; y < img.height && y < height; y++)
        {
            for (int x = 0; x < img.width && x < width; x++)
            {
                Color pixel = GetImageColor(img, x, y);
                // Preto = passável (0), Branco = bloqueado (255)
                float brightness = (pixel.r + pixel.g + pixel.b) / 3.0f;
                data[y * width + x] = (uint8_t)brightness;
            }
        }
        
        UnloadImage(img);
    }
    
    // Definir célula (grid-based)
    void setPassable(int gridX, int gridY, bool passable)
    {
        if (gridX < 0 || gridY < 0 || gridX >= width || gridY >= height)
            return;
        
        data[gridY * width + gridX] = passable ? 0 : 255;
    }
    
    // Verificar célula
    bool isPassable(int gridX, int gridY) const
    {
        if (gridX < 0 || gridY < 0 || gridX >= width || gridY >= height)
            return false;
        
        return data[gridY * width + gridX] < 128;  // < 50% brilho = passável
    }
    
    // Verificar hardness (0-255)
    uint8_t getHardness(int gridX, int gridY) const
    {
        if (gridX < 0 || gridY < 0 || gridX >= width || gridY >= height)
            return 255;
        
        return data[gridY * width + gridX];
    }
    
    // Converter mundo para grid
    void worldToGrid(float worldX, float worldY, int& gridX, int& gridY) const
    {
        gridX = (int)(worldX / tileSize);
        gridY = (int)(worldY / tileSize);
    }
    
    // Converter grid para mundo
    void gridToWorld(int gridX, int gridY, float& worldX, float& worldY) const
    {
        worldX = gridX * tileSize + tileSize / 2.0f;
        worldY = gridY * tileSize + tileSize / 2.0f;
    }
    
    // Renderizar mask (debug)
    void debugRender() const
    {
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                uint8_t val = data[y * width + x];
                Color c = {val, val, val, 255};
                DrawRectangle(x * tileSize, y * tileSize, tileSize, tileSize, c);
            }
        }
    }
};

// ===== PATHFINDING (A*) =====

struct PathNode
{
    int x, y;
    float gCost;    // Custo do start até aqui
    float hCost;    // Heurística até target
    float fCost;    // gCost + hCost
    PathNode* parent;
    
    PathNode(int px, int py, float g, float h, PathNode* p = nullptr)
        : x(px), y(py), gCost(g), hCost(h), fCost(g + h), parent(p) {}
};

class Pathfinder
{
private:
    PassabilityMask* mask;
    
    float heuristic(int x1, int y1, int x2, int y2)
    {
        // Manhattan distance
        return (float)(abs(x2 - x1) + abs(y2 - y1));
    }
    
    bool isWalkable(int x, int y)
    {
        return mask->isPassable(x, y);
    }
    
public:
    Pathfinder(PassabilityMask* m) : mask(m) {}
    
    // Encontrar caminho usando A*
    std::vector<std::pair<int, int>> findPath(int startX, int startY, int endX, int endY)
    {
        std::vector<std::pair<int, int>> path;
        
        if (!isWalkable(startX, startY) || !isWalkable(endX, endY))
            return path;  // Sem caminho
        
        std::vector<std::vector<PathNode*>> grid(mask->height, 
            std::vector<PathNode*>(mask->width, nullptr));
        
        std::vector<PathNode*> openSet;
        std::vector<std::vector<bool>> inOpenSet(mask->height, 
            std::vector<bool>(mask->width, false));
        std::vector<std::vector<bool>> closedSet(mask->height, 
            std::vector<bool>(mask->width, false));
        
        // Start node
        PathNode* start = new PathNode(startX, startY, 0, 
            heuristic(startX, startY, endX, endY), nullptr);
        openSet.push_back(start);
        inOpenSet[startY][startX] = true;
        grid[startY][startX] = start;
        
        // A* loop
        while (!openSet.empty())
        {
            // Find node with lowest fCost
            int current = 0;
            for (size_t i = 1; i < openSet.size(); i++)
            {
                if (openSet[i]->fCost < openSet[current]->fCost)
                    current = i;
            }
            
            PathNode* currentNode = openSet[current];
            
            // Chegou ao target?
            if (currentNode->x == endX && currentNode->y == endY)
            {
                // Reconstruir caminho
                PathNode* node = currentNode;
                while (node)
                {
                    path.insert(path.begin(), {node->x, node->y});
                    node = node->parent;
                }
                
                // Cleanup
                for (int y = 0; y < mask->height; y++)
                {
                    for (int x = 0; x < mask->width; x++)
                    {
                        if (grid[y][x]) delete grid[y][x];
                    }
                }
                
                return path;
            }
            
            openSet.erase(openSet.begin() + current);
            inOpenSet[currentNode->y][currentNode->x] = false;
            closedSet[currentNode->y][currentNode->x] = true;
            
            // Check neighbors (4 directions)
            int dx[] = {0, 0, 1, -1};
            int dy[] = {1, -1, 0, 0};
            
            for (int i = 0; i < 4; i++)
            {
                int nx = currentNode->x + dx[i];
                int ny = currentNode->y + dy[i];
                
                if (nx < 0 || ny < 0 || nx >= mask->width || ny >= mask->height)
                    continue;
                
                if (!isWalkable(nx, ny) || closedSet[ny][nx])
                    continue;
                
                float newG = currentNode->gCost + 1.0f;
                float h = heuristic(nx, ny, endX, endY);
                
                PathNode* neighbor = grid[ny][nx];
                
                if (!inOpenSet[ny][nx])
                {
                    neighbor = new PathNode(nx, ny, newG, h, currentNode);
                    grid[ny][nx] = neighbor;
                    openSet.push_back(neighbor);
                    inOpenSet[ny][nx] = true;
                }
                else if (newG < neighbor->gCost)
                {
                    neighbor->gCost = newG;
                    neighbor->fCost = newG + h;
                    neighbor->parent = currentNode;
                }
            }
        }
        
        // Sem caminho encontrado
        for (int y = 0; y < mask->height; y++)
        {
            for (int x = 0; x < mask->width; x++)
            {
                if (grid[y][x]) delete grid[y][x];
            }
        }
        
        return path;  // Empty path
    }
};

// ===== TILEMAP SYSTEM =====

struct Tile
{
    Graph* graphic;      // Gráfico do tile
    int tileID;          // ID do tipo de tile
    bool passable;       // Se é passável
    uint8_t hardness;    // 0-255 (quanto mais alto, mais difícil)
};

class Tilemap
{
private:
    int gridWidth, gridHeight;
    int tileWidth, tileHeight;
    std::vector<std::vector<Tile>> grid;
    PassabilityMask* passMask;
    Pathfinder* pathfinder;
    Graph* tileGraphicTemplate;
    
public:
    Tilemap(int gWidth, int gHeight, int tWidth, int tHeight)
        : gridWidth(gWidth), gridHeight(gHeight),
          tileWidth(tWidth), tileHeight(tHeight)
    {
        grid.resize(gHeight, std::vector<Tile>(gWidth));
        passMask = new PassabilityMask(gWidth, gHeight, tWidth);
        pathfinder = new Pathfinder(passMask);
        tileGraphicTemplate = nullptr;
        
        // Inicializar tiles
        for (int y = 0; y < gHeight; y++)
        {
            for (int x = 0; x < gWidth; x++)
            {
                grid[y][x] = {nullptr, 0, true, 0};
            }
        }
    }
    
    ~Tilemap()
    {
        if (passMask) delete passMask;
        if (pathfinder) delete pathfinder;
    }
    
    // Definir tile
    void setTile(int gridX, int gridY, int tileID, bool passable = true)
    {
        if (gridX < 0 || gridY < 0 || gridX >= gridWidth || gridY >= gridHeight)
            return;
        
        grid[gridY][gridX].tileID = tileID;
        grid[gridY][gridX].passable = passable;
        passMask->setPassable(gridX, gridY, passable);
    }
    
    // Obter tile
    Tile* getTile(int gridX, int gridY)
    {
        if (gridX < 0 || gridY < 0 || gridX >= gridWidth || gridY >= gridHeight)
            return nullptr;
        
        return &grid[gridY][gridX];
    }
    
    // Verificar passabilidade
    bool isPassable(int gridX, int gridY) const
    {
        return passMask->isPassable(gridX, gridY);
    }
    
    // Carregar mask de imagem
    void loadPassabilityMask(const char* filename)
    {
        passMask->loadFromImage(filename);
    }
    
    // Encontrar caminho (mundo -> grid)
    std::vector<std::pair<float, float>> findPath(float startX, float startY, 
                                                   float endX, float endY)
    {
        int sx, sy, ex, ey;
        passMask->worldToGrid(startX, startY, sx, sy);
        passMask->worldToGrid(endX, endY, ex, ey);
        
        auto gridPath = pathfinder->findPath(sx, sy, ex, ey);
        
        // Converter para world coordinates
        std::vector<std::pair<float, float>> worldPath;
        for (auto& node : gridPath)
        {
            float wx, wy;
            passMask->gridToWorld(node.first, node.second, wx, wy);
            worldPath.push_back({wx, wy});
        }
        
        return worldPath;
    }
    
    // Render tilemap
    void render(LayerSystem* layers, int layerIndex)
    {
        if (!tileGraphicTemplate)
            return;
        
        for (int y = 0; y < gridHeight; y++)
        {
            for (int x = 0; x < gridWidth; x++)
            {
                Tile* tile = &grid[y][x];
                if (tile->tileID > 0)
                {
                    float worldX = x * tileWidth + tileWidth / 2.0f;
                    float worldY = y * tileHeight + tileHeight / 2.0f;
                    
                    tileGraphicTemplate->setPosition(worldX, worldY);
                    // Render via tilemap (sem LayerSystem por agora)
                    tileGraphicTemplate->render();
                }
            }
        }
    }
    
    // Debug render
    void debugRender() const
    {
        passMask->debugRender();
        
        // Draw grid lines
        for (int x = 0; x <= gridWidth; x++)
        {
            DrawLineV(Vector2(x * tileWidth, 0), 
                      Vector2(x * tileWidth, gridHeight * tileHeight), GRAY);
        }
        for (int y = 0; y <= gridHeight; y++)
        {
            DrawLineV(Vector2(0, y * tileHeight), 
                      Vector2(gridWidth * tileWidth, y * tileHeight), GRAY);
        }
    }
    
    // Getters
    int getGridWidth() const { return gridWidth; }
    int getGridHeight() const { return gridHeight; }
    int getTileWidth() const { return tileWidth; }
    int getTileHeight() const { return tileHeight; }
    PassabilityMask* getMask() const { return passMask; }
};

// ===== PATHFINDING ENTITY (EXEMPLO) =====

class PathfindingEntity
{
public:
    float x, y;
    std::vector<std::pair<float, float>> path;
    size_t pathIndex;
    float speed;
    Tilemap* tilemap;
    
    PathfindingEntity(Tilemap* tm) 
        : x(0), y(0), pathIndex(0), speed(100.0f), tilemap(tm) {}
    
    // Começar a seguir um caminho
    void followPath(float targetX, float targetY)
    {
        path = tilemap->findPath(x, y, targetX, targetY);
        pathIndex = 0;
    }
    
    // Update movimento
    void update(float dt)
    {
        if (path.empty() || pathIndex >= path.size())
            return;
        
        auto& target = path[pathIndex];
        float dx = target.first - x;
        float dy = target.second - y;
        float dist = sqrt(dx * dx + dy * dy);
        
        if (dist < 5.0f)
        {
            pathIndex++;
            if (pathIndex >= path.size())
            {
                x = target.first;
                y = target.second;
                return;
            }
            target = path[pathIndex];
            dx = target.first - x;
            dy = target.second - y;
            dist = sqrt(dx * dx + dy * dy);
        }
        
        if (dist > 0.01f)
        {
            x += (dx / dist) * speed * dt;
            y += (dy / dist) * speed * dt;
        }
    }
    
    bool hasPath() const { return !path.empty(); }
    bool pathComplete() const { return pathIndex >= path.size(); }
};
