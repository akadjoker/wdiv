# 🗺️ Mask + Pathfinding + Tilemap - Guia Completo

## O que é?

Um sistema completo para criar níveis com:
- **Máscara de passabilidade** (preto/branco) para definir colisões
- **Pathfinding A*** para encontrar caminhos
- **TilemapSystem** para gerenciar tiles e entidades

```
Máscara (Preto/Branco)    A* Pathfinding         Entidades
┌──────────────────┐      ┌──────────────────┐    ┌──────────────┐
│ ██████░░░░░░░░░░│      │ Start            │    │ Player       │
│ ░░░░░░░░░░░░░░░░│  →   │   ↓              │  → │ Enemies      │
│ ░░███████░░░░░░░│      │ [Path]           │    │ (pathfinding)│
│ ░░░░░░░░░░███░░░│      │   ↓              │    │              │
└──────────────────┘      │  End             │    └──────────────┘
Preto=bloqueado          └──────────────────┘
Branco=passável
```


## Componentes

### PassabilityMask
```cpp
// Criar máscara (40x22 grid, tiles 32x32)
PassabilityMask mask(40, 22, 32);

// Carregar de imagem
mask.loadFromImage("level_mask.png");

// Ou definir manualmente
mask.setPassable(5, 10, false);  // Bloquear célula

// Verificar
bool canWalk = mask.isPassable(5, 10);
```

### Pathfinder (A*)
```cpp
Pathfinder pathfinder(&mask);

// Encontrar caminho
auto path = pathfinder.findPath(
    startGridX, startGridY,
    endGridX, endGridY
);
// Retorna: vector<pair<int, int>> com grid coordinates
```

### Tilemap
```cpp
// Criar tilemap
Tilemap tilemap(gridWidth, gridHeight, tileWidth, tileHeight);

// Definir tiles
tilemap.setTile(x, y, tileID, passable);

// Encontrar caminho (world coordinates)
auto worldPath = tilemap.findPath(startX, startY, endX, endY);
// Retorna: vector<pair<float, float>> com world coordinates

// Carregar máscara de imagem
tilemap.loadPassabilityMask("mask.png");
```

### PathfindingEntity
```cpp
PathfindingEntity entity(&tilemap);
entity.x = 100;
entity.y = 100;
entity.speed = 100.0f;

// Seguir caminho
entity.followPath(targetX, targetY);

// Update
entity.update(dt);  // Move automaticamente

// Check status
bool moving = entity.hasPath();
bool done = entity.pathComplete();
```


## Setup Mínimo

```cpp
// 1. Criar tilemap
Tilemap tilemap(40, 22, 32, 32);

// 2. Carregar máscara
tilemap.loadPassabilityMask("level.png");

// 3. Criar entidade
PathfindingEntity player(&tilemap);
player.x = 100;
player.y = 100;

// 4. Update
while (!WindowShouldClose()) {
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        player.followPath(GetMouseX(), GetMouseY());
    }
    
    player.update(dt);
    
    BeginDrawing();
    ClearBackground(BLACK);
    DrawCircle((int)player.x, (int)player.y, 10, BLUE);
    EndDrawing();
}
```


## Criar Máscara (Imagem Preto/Branco)

### Opção 1: Ficheiro PNG
```
Editor (Photoshop, GIMP, Aseprite):
1. Criar imagem (40x22 pixels para 40x22 grid)
2. Desenhar com preto/branco
   - Preto (#000000) = passável
   - Branco (#FFFFFF) = bloqueado
3. Salvar como level_mask.png

Código:
tilemap.loadPassabilityMask("level_mask.png");
```

### Opção 2: Gerar em Código
```cpp
// Criar imagem
Image maskImage = GenImageColor(gridW, gridH, BLACK);

// Desenhar obstáculos (branco)
for (int x = 10; x < 20; x++) {
    ImageDrawPixel(&maskImage, x, 10, WHITE);  // Parede horizontal
}

// Salvar
ExportImage(maskImage, "level.png");

// Carregar
tilemap.loadPassabilityMask("level.png");
```

### Opção 3: Definir Manualmente
```cpp
// Sem máscara de imagem
for (int x = 10; x < 20; x++) {
    tilemap.setTile(x, 10, 2, false);  // Não passável
}
```


## Algoritmo A*

O pathfinding usa **A*** (A-star):

1. **Start Node** - Posição inicial
2. **Open List** - Nós a explorar
3. **Closed List** - Nós já explorados
4. **Heurística** - Manhattan distance para target
5. **Cost** - gCost (distância) + hCost (estimativa)

```
Pseudocódigo:

A*(start, goal):
    openSet = [start]
    
    while openSet não vazio:
        current = nó com fCost mínimo em openSet
        
        if current == goal:
            return caminho reconstruído
        
        move current de openSet para closedSet
        
        for each vizinho de current:
            if vizinho é bloqueado ou em closedSet:
                continue
            
            newG = current.g + 1
            if vizinho não em openSet:
                vizinho.parent = current
                openSet.add(vizinho)
            elif newG < vizinho.g:
                vizinho.parent = current
                vizinho.g = newG
    
    return caminho vazio  // Sem caminho
```

**Complexidade:** O(width * height * log(n))
**Garantido:** Encontra o caminho mais curto


## Exemplo Prático: Inimigos Inteligentes

```cpp
class Enemy {
public:
    PathfindingEntity pathEntity;
    Tilemap* tilemap;
    float updateTimer;
    float updateInterval;  // Recalcular pathfinding a cada X segundos
    
    Enemy(Tilemap* tm) : tilemap(tm), updateTimer(0), updateInterval(0.5f) {}
    
    void update(float dt, float playerX, float playerY) {
        updateTimer += dt;
        
        if (updateTimer >= updateInterval) {
            // Recalcular caminho para o player
            pathEntity.followPath(playerX, playerY);
            updateTimer = 0;
        }
        
        // Mover ao longo do caminho
        pathEntity.update(dt);
    }
    
    void render() {
        DrawCircle((int)pathEntity.x, (int)pathEntity.y, 8, RED);
    }
};

// Uso:
std::vector<Enemy> enemies;
for (int i = 0; i < 5; i++) {
    enemies.push_back(Enemy(&tilemap));
}

// No loop:
for (auto& enemy : enemies) {
    enemy.update(dt, player.x, player.y);
    enemy.render();
}
```


## Performance Tips

### 1. Não Recalcular Muito Frequentemente
```cpp
// BAD - recalcula a cada frame
if (true) {
    entity.followPath(target.x, target.y);
}

// GOOD - recalcula a cada segundo
updateTimer += dt;
if (updateTimer >= 1.0f) {
    entity.followPath(target.x, target.y);
    updateTimer = 0;
}
```

### 2. Cache Paths
```cpp
// Se target não se moveu, não recalcula
if (lastTargetX != currentTargetX || lastTargetY != currentTargetY) {
    entity.followPath(currentTargetX, currentTargetY);
    lastTargetX = currentTargetX;
    lastTargetY = currentTargetY;
}
```

### 3. Limite de Busca
```cpp
// Para grandes mapas, limitar busca
// (não implementado aqui, mas útil)
// Usar Jump Point Search ou Theta*
```

### 4. Pathfinding em Background
```cpp
// Para jogos com muitos inimigos:
// - Usar threading
// - Ou distribuir pathfinding entre múltiplos frames
// - Ou usar pathfinding simplificado
```


## Integração com Entidades

```cpp
struct GameEntity {
    PathfindingEntity pathfinding;
    Graph* graphic;
    float health;
    
    GameEntity(Tilemap* tm) : pathfinding(tm) {}
    
    void update(float dt) {
        pathfinding.update(dt);
        
        if (graphic) {
            graphic->setPosition(pathfinding.x, pathfinding.y);
        }
    }
    
    void followPlayer(float playerX, float playerY) {
        pathfinding.followPath(playerX, playerY);
    }
};
```


## Casos de Uso

### 1. Inimigos Inteligentes
```cpp
enemy.followPath(player.x, player.y);
```

### 2. NPCs Patrulhando
```cpp
if (enemy.pathComplete()) {
    int nextWaypointX = waypoints[nextIndex].x;
    int nextWaypointY = waypoints[nextIndex].y;
    enemy.followPath(nextWaypointX, nextWaypointY);
    nextIndex = (nextIndex + 1) % waypoints.size();
}
```

### 3. Puzzle: Encontrar Saída
```cpp
auto exitPath = tilemap.findPath(player.x, player.y, exitX, exitY);
if (exitPath.empty()) {
    DrawText("NO PATH TO EXIT!", 100, 100, 20, RED);
}
```

### 4. Mapa Dinâmico
```cpp
// Blocos que aparecem/desaparecem
if (blockFalls) {
    tilemap.setTile(x, y, 2, false);  // Bloquear
    // Inimigos agora não conseguem passar
}
```


## Debug & Visualização

```cpp
// Mostrar máscara de passabilidade
tilemap.getMask()->debugRender();

// Mostrar caminho do player
if (showPath && player.hasPath()) {
    for (size_t i = 0; i < player.path.size() - 1; i++) {
        DrawLineV(Vector2(player.path[i].first, player.path[i].second),
                 Vector2(player.path[i + 1].first, player.path[i + 1].second),
                 YELLOW);
    }
}

// Mostrar grid
for (int x = 0; x <= gridWidth; x++) {
    DrawLineV(Vector2(x * tileSize, 0), Vector2(x * tileSize, gridHeight * tileSize), GRAY);
}
```


## Compilação

```bash
g++ -std=c++17 exemplo_pathfinding_tilemap.cpp Graph.cpp -o game -lraylib -lm
```


## API Rápida

### PassabilityMask
```cpp
mask.loadFromImage("file.png");
mask.setPassable(gridX, gridY, bool);
bool isPass = mask.isPassable(gridX, gridY);
uint8_t hardness = mask.getHardness(gridX, gridY);
mask.worldToGrid(worldX, worldY, outGridX, outGridY);
mask.gridToWorld(gridX, gridY, outWorldX, outWorldY);
mask.debugRender();
```

### Pathfinder
```cpp
auto path = pathfinder.findPath(sx, sy, ex, ey);
// Retorna: vector<pair<int, int>>
```

### Tilemap
```cpp
tilemap.setTile(x, y, id, passable);
Tile* tile = tilemap.getTile(x, y);
bool pass = tilemap.isPassable(x, y);
tilemap.loadPassabilityMask("mask.png");
auto worldPath = tilemap.findPath(startX, startY, endX, endY);
```

### PathfindingEntity
```cpp
entity.followPath(targetX, targetY);
entity.update(dt);
bool moving = entity.hasPath();
bool done = entity.pathComplete();
entity.speed = 100.0f;
```


## Ficheiros

```
TilemapPathfinding.h          - Classes principais
exemplo_pathfinding_tilemap.cpp - Demo básica
exemplo_mask_advanced.cpp      - Demo avançada com máscara
```


## Próximas Ideias

- **Steering Behaviors** - Movimento mais natural
- **Jump Point Search** - Pathfinding mais rápido
- **Theta*** - Caminhos suavizados
- **Dinâmico Obstacles** - Blocos que aparecem
- **Multiagent** - Múltiplos agentes evitando colisões
- **Hierarchical Pathfinding** - Para mapas grandes

---

**Sistema de Pathfinding completo e pronto!** 🗺️✨

